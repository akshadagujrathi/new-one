import { Route, Routes } from 'react-router-dom';
import './App.css';
import Header from './components/Header';
import Home from './Pages/Home'
import SearchResult from './components/Home/SearchResult'; // Adjusted import path
import JobSearch from './components/Home/Search';
import JobPage from './Pages/JobPage';

function App() {
  
  return (
    <div className="App">
      <Header />
      <Routes>
        <Route index element={<Home />} />
        <Route exact path="/" component={JobSearch} />
        <Route path="/SearchResult" element={<SearchResult />} /> 
        {/* <Route path="/JobPage/SinglejobPost/:id" element={<SinglejobPost />} /> */}
        <Route path='/JobPage/SinglejobPost/:id' element={<JobPage />}/>
      </Routes>
    </div>
  );
}

export default App;
