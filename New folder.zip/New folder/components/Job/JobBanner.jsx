import React from 'react';
import jobsData from '../Home/jobs';
import { useParams } from 'react-router-dom';
const JobBanner = () => { 

   const { id } = useParams();
    const jobId = parseInt(id);
    const job = jobsData.find(job => job.id === jobId);

    if (!job) {
        return (
            <div className="container">
                <h2>Job not found</h2>
            </div>
        );
    }
    return (
        
             <div className='container'>
                <div className='row' key={job.id}>
                    <h2 className='text-white'>{job.jobTitle}</h2> 
                </div>
            </div>
       
    );
}

export default JobBanner;
