import React from 'react';
import { useLocation, Link } from 'react-router-dom';

const SearchResults = () => {
    const location = useLocation();
    const results = location.state?.results;

    if (!results || results.length === 0) {
        return (
            <div className='container my-5'>
                <h1 className='text-center' >No search results found.</h1>
                <p  className='text-center'>Please go back and try again.</p>
            </div>
        );
    }

    return (
        <div className='container-fluid '>
           
            <div className=' m-5'>
            <h1 className='text-center'>Search Results</h1>
                {results.map(job => (
                    <div key={job.id} className="job-post">
                          <Link to={`/JobPage/SinglejobPost/${job.id}`}>
                            <h6 className='text-left'>{job.jobTitle} at {job.company}</h6>
                        </Link>
                        <h6 className='text-left'>{job.jobTitle} at {job.company}</h6>
                        <p className='text-left'>{job.description}</p>
                        <p className='text-left'>Location: {job.location}</p>
                        <p className='text-left'>Salary: {job.salary}</p>
                        <p className='text-left'>Job Type: {job.type}</p>
                        {/* Add more job details as needed */}
                       
                    </div>
                    
                ))}
            </div>
        </div>
    );
};

export default SearchResults;
