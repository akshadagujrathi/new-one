import React from 'react';
import JobSearch from './Search';

const Banner = () => {
   
    
    return (
        <section className='banner'>
            <div className='container'>
            <div className='row text-center'>
                <h1 className='text-white'>The Easiest Way To Get Your Dream Job</h1>
                <p className='text-white my-5'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit, cum?</p>
                <JobSearch />
            </div>
           
        </div>
        </section>
        
    );
}

export default Banner;
