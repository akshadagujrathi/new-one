const jobsData = [
  {
    id: 1,
    jobTitle: "Software Engineer",
    company: "Puma Tech",
    location: "New York, NY",
    salary: "$80,000 - $100,000",
    logo: require("../../images/Puma_logo.webp"),
    abt_company:"Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words",
    requirements: {
      education: "Bachelor's degree in Computer Science or related field",
      experience: "2+ years of experience in software development",
      skills: ["JavaScript", "React", "Node.js", "SQL"],
    },
    description:
      "ABC Tech is seeking a talented Software Engineer to join our team. Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words",
    responsibilities: [
      "Develop new features for our web applications",
      "Maintain and improve existing codebase",
      "Collaborate with cross-functional teams to define, design, and ship new features"
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for professional growth and development",
      "Dynamic and collaborative work environment",
    ],
    howToApply:
      "Please send your resume and cover letter to careers@abctech.com",
    type: "full-time",
    posted: "25-04-2024",
    deadline:"20-05-2024"
  },
  {
    id: 19,
    jobTitle: "Frontend Developer",
    company: "XYZ Solutions",
    location: "San Francisco, CA",
    salary: "$90,000 - $110,000",
    requirements: {
      education: "Bachelor's degree in Computer Science or related field",
      experience: "3+ years of experience in frontend development",
      skills: ["HTML", "CSS", "JavaScript", "React"],
    },
    description:
      "XYZ Solutions is looking for an experienced Frontend Developer to...",
    responsibilities: [
      "Develop user-friendly web interfaces",
      "Collaborate with back-end developers and UI/UX designers",
      "Optimize application performance and scalability",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Flexible work hours",
      "Health and wellness programs",
    ],
    howToApply:
      "To apply, please submit your resume and portfolio to jobs@xyzsolutions.com",
    type: "full-time",
    posted: "15-02-2015",
  },
  {
    id: 2,
    jobTitle: "Data Scientist",
    company: "Data Insights Inc.",
    location: "Chicago, IL",
    salary: "$100,000 - $120,000",
    requirements: {
      education:
        "Master's or Ph.D. in Computer Science, Statistics, Mathematics, or related field",
      experience:
        "5+ years of experience in data analysis and machine learning",
      skills: ["Python", "R", "Machine Learning", "Data Visualization"],
    },
    description:
      "Data Insights Inc. is seeking a skilled Data Scientist to lead our...",
    responsibilities: [
      "Analyze large datasets to extract actionable insights",
      "Develop predictive models and machine learning algorithms",
      "Visualize and communicate findings to stakeholders",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity to work on cutting-edge projects",
      "Flexible work environment",
    ],
    howToApply:
      "Interested candidates, please submit your resume and cover letter to careers@datainsights.com",
    type: "full-time",
    posted: "10-03-2015",
  },
  {
    id: 3,
    jobTitle: "UX/UI Designer",
    company: "Creative Solutions",
    location: "Los Angeles, CA",
    salary: "$70,000 - $90,000",
    requirements: {
      education:
        "Bachelor's degree in Graphic Design, Web Design, or related field",
      experience: "2+ years of experience in UX/UI design",
      skills: ["UI/UX Design", "Adobe XD", "Sketch", "InVision"],
    },
    description:
      "Creative Solutions is looking for a talented UX/UI Designer to create...",
    responsibilities: [
      "Design intuitive and engaging user interfaces",
      "Collaborate with product managers and developers",
      "Conduct user research and usability testing",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for career advancement",
      "Flexible work schedule",
    ],
    howToApply:
      "To apply, please send your portfolio and resume to careers@creativesolutions.com",
    type: "full-time",
    posted: "05-04-2015",
  },
  {
    id: 4,
    jobTitle: "Backend Developer",
    company: "Tech Innovations",
    location: "Seattle, WA",
    salary: "$85,000 - $105,000",
    requirements: {
      education: "Bachelor's degree in Computer Science or related field",
      experience: "3+ years of experience in backend development",
      skills: ["Java", "Spring Boot", "RESTful APIs", "SQL"],
    },
    description:
      "Tech Innovations is hiring a Backend Developer to join our dynamic team...",
    responsibilities: [
      "Develop and maintain scalable backend services",
      "Optimize application performance and reliability",
      "Collaborate with frontend developers and product managers",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for professional growth",
      "Flexible work hours",
    ],
    howToApply:
      "Interested candidates, please submit your resume to careers@techinnovations.com",
    type: "full-time",
    posted: "01-05-2015",
  },
  {
    id: 5,
    jobTitle: "Mobile App Developer",
    company: "AppWorks",
    location: "Austin, TX",
    salary: "$90,000 - $110,000",
    requirements: {
      education: "Bachelor's degree in Computer Science or related field",
      experience: "3+ years of experience in mobile app development",
      skills: ["iOS Development", "Swift", "Android Development", "Kotlin"],
    },
    description:
      "AppWorks is seeking a talented Mobile App Developer to join our team...",
    responsibilities: [
      "Develop native mobile applications for iOS and Android platforms",
      "Collaborate with designers and backend developers",
      "Optimize application performance and usability",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity to work on cutting-edge projects",
      "Flexible work environment",
    ],
    howToApply:
      "To apply, please send your resume and portfolio to jobs@appworks.com",
    type: "full-time",
    posted: "15-06-2015",
  },
  {
    id: 6,
    jobTitle: "DevOps Engineer",
    company: "Cloud Systems Inc.",
    location: "Denver, CO",
    salary: "$95,000 - $115,000",
    requirements: {
      education: "Bachelor's degree in Computer Science or related field",
      experience: "3+ years of experience in DevOps or related role",
      skills: ["Linux", "Docker", "Kubernetes", "CI/CD"],
    },
    description:
      "Cloud Systems Inc. is looking for a skilled DevOps Engineer to...",
    responsibilities: [
      "Implement and maintain CI/CD pipelines",
      "Manage containerized applications with Docker and Kubernetes",
      "Troubleshoot and resolve infrastructure issues",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for career advancement",
      "Flexible work schedule",
    ],
    howToApply: "To apply, please send your resume to careers@cloudsystems.com",
    type: "full-time",
    posted: "20-07-2015",
  },
  {
    id: 7,
    jobTitle: "Product Manager",
    company: "Innovate Solutions",
    location: "Boston, MA",
    salary: "$100,000 - $120,000",
    requirements: {
      education:
        "Bachelor's degree in Business Administration, Computer Science, or related field",
      experience: "5+ years of experience in product management",
      skills: ["Product Management", "Agile", "Scrum", "Market Analysis"],
    },
    description:
      "Innovate Solutions is seeking an experienced Product Manager to...",
    responsibilities: [
      "Define product vision, strategy, and roadmap",
      "Gather and prioritize product requirements",
      "Work closely with engineering and design teams to deliver high-quality products",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for professional growth",
      "Flexible work schedule",
    ],
    howToApply:
      "Interested candidates, please submit your resume to careers@innovatesolutions.com",
    type: "full-time",
    posted: "05-08-2015",
  },
  {
    id: 8,
    jobTitle: "Network Engineer",
    company: "Networking Solutions LLC",
    location: "Houston, TX",
    salary: "$85,000 - $105,000",
    requirements: {
      education:
        "Bachelor's degree in Computer Science, Information Technology, or related field",
      experience: "3+ years of experience in network engineering",
      skills: ["Cisco", "CCNA", "Network Security", "TCP/IP"],
    },
    description:
      "Networking Solutions LLC is hiring a Network Engineer to join our team...",
    responsibilities: [
      "Design and implement network infrastructure",
      "Configure and troubleshoot network devices",
      "Ensure network security and compliance",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for career growth",
      "Flexible work hours",
    ],
    howToApply:
      "To apply, please send your resume to careers@networkingsolutions.com",
    type: "part-time",
    posted: "10-09-2015",
  },
  {
    id: 9,
    jobTitle: "Sales Representative",
    company: "Sales Solutions Inc.",
    location: "Atlanta, GA",
    salary: "$60,000 - $80,000",
    requirements: {
      education:
        "Bachelor's degree in Business Administration, Marketing, or related field",
      experience: "2+ years of experience in sales",
      skills: ["Sales", "Negotiation", "Customer Relationship Management"],
    },
    description:
      "Sales Solutions Inc. is looking for a motivated Sales Representative to...",
    responsibilities: [
      "Generate leads and drive sales revenue",
      "Build and maintain relationships with clients",
      "Prepare and deliver sales presentations",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Uncapped commission structure",
      "Opportunity for career advancement",
    ],
    howToApply:
      "To apply, please send your resume to careers@salessolutions.com",
    type: "full-time",
    posted: "15-10-2015",
  },
  {
    id: 10,
    jobTitle: "Graphic Designer",
    company: "Creative Designs Co.",
    location: "Miami, FL",
    salary: "$50,000 - $70,000",
    requirements: {
      education: "Bachelor's degree in Graphic Design or related field",
      experience: "2+ years of experience in graphic design",
      skills: [
        "Adobe Creative Suite",
        "Typography",
        "Illustration",
        "Layout Design",
      ],
    },
    description:
      "Creative Designs Co. is seeking a talented Graphic Designer to create...",
    responsibilities: [
      "Develop visual concepts and designs for print and digital media",
      "Collaborate with clients and stakeholders to understand project requirements",
      "Produce high-quality graphics and artwork",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity to work on diverse projects",
      "Flexible work environment",
    ],
    howToApply:
      "To apply, please send your portfolio and resume to careers@creativedesigns.com",
    type: "full-time",
    posted: "20-11-2015",
  },
  {
    id: 11,
    jobTitle: "Financial Analyst",
    company: "Financial Services LLC",
    location: "Dallas, TX",
    salary: "$70,000 - $90,000",
    requirements: {
      education:
        "Bachelor's degree in Finance, Accounting, Economics, or related field",
      experience: "2+ years of experience in financial analysis",
      skills: [
        "Financial Modeling",
        "Data Analysis",
        "Excel",
        "Financial Reporting",
      ],
    },
    description:
      "Financial Services LLC is hiring a Financial Analyst to support our...",
    responsibilities: [
      "Analyze financial data and prepare reports",
      "Develop financial models and forecasts",
      "Assist in budgeting and financial planning processes",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for career growth",
      "Flexible work schedule",
    ],
    howToApply:
      "To apply, please send your resume to careers@financialservices.com",
    type: "full-time",
    posted: "25-12-2015",
  },
  {
    id: 12,
    jobTitle: "HR Manager",
    company: "HR Solutions Inc.",
    location: "Philadelphia, PA",
    salary: "$80,000 - $100,000",
    requirements: {
      education:
        "Bachelor's degree in Human Resources, Business Administration, or related field",
      experience: "5+ years of experience in human resources",
      skills: [
        "Recruitment",
        "Employee Relations",
        "Performance Management",
        "HR Policies",
      ],
    },
    description:
      "HR Solutions Inc. is seeking an experienced HR Manager to oversee our...",
    responsibilities: [
      "Develop and implement HR policies and procedures",
      "Manage recruitment and onboarding processes",
      "Provide guidance and support to employees and management",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for career advancement",
      "Flexible work environment",
    ],
    howToApply: "To apply, please send your resume to careers@hrsolutions.com",
    type: "full-time",
    posted: "30-01-2016",
  },
  {
    id: 13,
    jobTitle: "Content Writer",
    company: "Content Creators Co.",
    location: "Seattle, WA",
    salary: "$60,000 - $80,000",
    requirements: {
      education:
        "Bachelor's degree in English, Journalism, Communications, or related field",
      experience: "2+ years of experience in content writing",
      skills: ["Copywriting", "Content Editing", "SEO", "Social Media"],
    },
    description:
      "Content Creators Co. is looking for a talented Content Writer to produce...",
    responsibilities: [
      "Create engaging and SEO-friendly content for websites and blogs",
      "Edit and proofread content to ensure accuracy and consistency",
      "Promote content on social media platforms",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity to work on diverse projects",
      "Flexible work schedule",
    ],
    howToApply:
      "To apply, please send your resume and writing samples to careers@contentcreators.com",
    type: "full-time",
    posted: "05-02-2016",
  },
  {
    id: 14,
    jobTitle: "Customer Support Specialist",
    company: "Customer Care Solutions",
    location: "San Francisco, CA",
    salary: "$50,000 - $70,000",
    requirements: {
      education:
        "Bachelor's degree in Business Administration, Communication, or related field",
      experience: "2+ years of experience in customer service or support",
      skills: [
        "Customer Service",
        "Problem-Solving",
        "Communication",
        "CRM Software",
      ],
    },
    description:
      "Customer Care Solutions is hiring a Customer Support Specialist to...",
    responsibilities: [
      "Respond to customer inquiries via phone, email, and chat",
      "Resolve customer issues and complaints in a timely manner",
      "Provide product information and assistance",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for career advancement",
      "Flexible work schedule",
    ],
    howToApply: "To apply, please send your resume to careers@customercare.com",
    type: "full-time",
    posted: "10-03-2016",
  },
  {
    id: 15,
    jobTitle: "Quality Assurance Analyst",
    company: "Quality Solutions Inc.",
    location: "Chicago, IL",
    salary: "$70,000 - $90,000",
    requirements: {
      education:
        "Bachelor's degree in Computer Science, Information Technology, or related field",
      experience:
        "2+ years of experience in software testing or quality assurance",
      skills: [
        "Software Testing",
        "Test Automation",
        "Bug Tracking",
        "QA Processes",
      ],
    },
    description:
      "Quality Solutions Inc. is seeking a skilled Quality Assurance Analyst to...",
    responsibilities: [
      "Develop and execute test cases and test plans",
      "Identify and report bugs and issues",
      "Collaborate with development and product teams to ensure product quality",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for career growth",
      "Flexible work hours",
    ],
    howToApply:
      "To apply, please send your resume to careers@qualitysolutions.com",
    type: "full-time",
    posted: "15-04-2016",
  },
  {
    id: 16,
    jobTitle: "Legal Counsel",
    company: "Legal Services LLC",
    location: "Washington, D.C.",
    salary: "$100,000 - $120,000",
    requirements: {
      education: "Juris Doctor (JD) degree and active state bar membership",
      experience: "5+ years of experience in corporate law or related field",
      skills: [
        "Legal Research",
        "Contract Negotiation",
        "Compliance",
        "Corporate Governance",
      ],
    },
    description:
      "Legal Services LLC is hiring a Legal Counsel to provide legal advice and support...",
    responsibilities: [
      "Draft and review legal documents and contracts",
      "Provide legal guidance on business matters",
      "Ensure compliance with laws and regulations",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for career advancement",
      "Flexible work environment",
    ],
    howToApply:
      "To apply, please send your resume to careers@legalservices.com",
    type: "full-time",
    posted: "20-05-2016",
  },
  {
    id: 17,
    jobTitle: "Marketing Manager",
    company: "Marketing Solutions Inc.",
    location: "New York, NY",
    salary: "$90,000 - $110,000",
    requirements: {
      education:
        "Bachelor's degree in Marketing, Business Administration, or related field",
      experience: "5+ years of experience in marketing",
      skills: [
        "Marketing Strategy",
        "Digital Marketing",
        "Campaign Management",
        "Analytics",
      ],
    },
    description:
      "Marketing Solutions Inc. is seeking an experienced Marketing Manager to...",
    responsibilities: [
      "Develop and execute marketing strategies and campaigns",
      "Analyze campaign performance and make data-driven decisions",
      "Manage marketing budget and resources",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for career growth",
      "Flexible work schedule",
    ],
    howToApply:
      "To apply, please send your resume to careers@marketingsolutions.com",
    type: "full-time",
    posted: "25-06-2016",
  },
  {
    id: 18,
    jobTitle: "UI Designer",
    company: "UI Innovations",
    location: "Seattle, WA",
    salary: "$80,000 - $100,000",
    requirements: {
      education:
        "Bachelor's degree in Graphic Design, Web Design, or related field",
      experience: "3+ years of experience in UI/UX design",
      skills: ["UI Design", "Adobe XD", "Sketch", "InVision"],
    },
    description:
      "UI Innovations is looking for a talented UI Designer to create...",
    responsibilities: [
      "Design user interfaces for web and mobile applications",
      "Collaborate with cross-functional teams to define design requirements",
      "Create wireframes, prototypes, and mockups",
    ],
    benefits: [
      "Competitive salary and benefits package",
      "Opportunity for career advancement",
      "Flexible work environment",
    ],
    howToApply:
      "To apply, please send your portfolio and resume to careers@uiinnovations.com",
    type: "full-time",
    posted: "30-07-2016",
  },
];
export default jobsData;
