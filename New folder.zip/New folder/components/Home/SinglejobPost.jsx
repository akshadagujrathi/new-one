import React from 'react';
import jobsData from './jobs';
import { useParams } from 'react-router-dom';
import { MdOutlineWorkOutline } from "react-icons/md";
import { SlLocationPin } from "react-icons/sl";
import { WiTime9 } from "react-icons/wi";
import { CiHeart } from "react-icons/ci";

const SinglejobPost = () => {
    const { id } = useParams(); // Extract the job ID from the URL parameters
    const jobId = parseInt(id);
    const job = jobsData.find(job => job.id === jobId);

    if (!job) {
        return (
            <div className="container">
                <h2>Job not found</h2>
            </div>
        );
    }

    // Convert skills array to comma-separated string
    const skillsString = job.requirements.skills.join(", ");

    return (
        <div className="container">
            <div className='row d-flex align-items-center'>
                <div className='col-12 col-md-8 d-flex align-items-center'>
                    <div className='col-3 col-md-3'>
                        <img className='img-fluid' src={job.logo} alt={job.jobTitle} />
                    </div>
                    <div className='col-9 col-md-7'>
                        <h4>{job.jobTitle}</h4>
                        <div className='d-flex gap-4'>
                            <p><MdOutlineWorkOutline className='me-2'/>{job.company}</p>
                            <p><SlLocationPin className='me-2'/>{job.location}</p>
                            <p className='text-success'><WiTime9 className='me-2' />{job.type}</p>
                        </div>
                    </div>
                </div>
                <div className='d-flex col-12 col-md-4 gap-3'>
                    <button className='btn border'><CiHeart className='me-2 text-danger'/>Save Job</button>
                    <button className='btn btn-success'>Apply Now</button>
                </div>
            </div>
            <div className='row d-flex'>
                <div className='col-12 col-md-8'>
                    <h4 className='text-success'>Job Description</h4>
                    <p>{job.description}</p>
                    <h4 className='text-success'>Responsibilities</h4>
                    <ul>
                        {job.responsibilities.map((responsibility, index) => (
                            <li key={index}>{responsibility}</li>
                        ))}
                    </ul>
                    <h4 className='text-success'>Requirements</h4>
                    <ul>
                        <li>Education: {job.requirements.education}</li>
                        <li>Experience: {job.requirements.experience}</li>
                        <li>Skills: {skillsString}</li>
                    </ul>
                    <h4 className='text-success'>Benefits</h4>
                    <ul>
                        {job.benefits.map((benefit, index) => (
                            <li key={index}>{benefit}</li>
                        ))}
                    </ul>
                </div>
                <div className='col-12 col-md-4'>
                    <div className='job-summary'>
                    <h4 className='text-success'>Job Summary</h4>
                    <p><strong>Posted on:</strong> {job.posted}</p>
                    <p><strong>Type</strong> {job.type}</p>
                    <p><strong>Experience</strong> {job.requirements.experience}</p>
                    <p><strong>Location</strong> {job.location}</p>
                    <p><strong>Salary</strong> {job.salary}</p>
                    <p><strong>Deadline</strong> {job.deadline}</p>
                    </div>
                    
                </div>
            </div>
        </div>
    );
};

export default SinglejobPost;
