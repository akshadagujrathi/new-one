import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import jobsData from './jobs'; // Assuming this is your JSON data
import { IoIosSearch } from "react-icons/io";
const JobSearch = () => {
    const navigate = useNavigate();
    const [searchCriteria, setSearchCriteria] = useState({
        jobTitle: '',
        company: '',
        jobType: 'All',
        skills: '',
        locations: ''
    });
    const [error, setError] = useState('');

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setSearchCriteria({ ...searchCriteria, [name]: value });
    };

    const handleSearch = () => {
        if (!searchCriteria.jobTitle && !searchCriteria.company && !searchCriteria.locations && searchCriteria.jobType === 'All' && !searchCriteria.skills) {
            setError('Please fill at least one field or select a job type.');
        } else {
            const filteredJobs = jobsData.filter(job => {
                const titleMatch = searchCriteria.jobTitle === '' ? true : searchCriteria.jobTitle.toLowerCase().split(',').map(t => t.trim()).some(title => job.jobTitle.toLowerCase().includes(title));
                const companyMatch = searchCriteria.company === '' ? true : searchCriteria.company.toLowerCase().split(',').map(c => c.trim()).some(company => job.company.toLowerCase().includes(company));
                const typeMatch = searchCriteria.jobType === 'All' ? true : job.type.toLowerCase() === searchCriteria.jobType.toLowerCase() || job.type.toLowerCase() === 'part-time';
                const skillsMatch = searchCriteria.skills === '' ? true : job.requirements.skills.some(skill => {
                    return searchCriteria.skills.toLowerCase().split(',').map(s => s.trim()).includes(skill.toLowerCase());
                });
    
                let locationMatch = true;
                if (searchCriteria.locations !== '') {
                    const searchLocations = searchCriteria.locations.toLowerCase().split(',').map(l => l.trim());
                    locationMatch = searchLocations.some(searchLocation => job.location.toLowerCase().includes(searchLocation));
                }
    
                return titleMatch && companyMatch && typeMatch && skillsMatch && locationMatch;
            });
    
            // Navigate to SearchResults component with the filtered jobs as state
            navigate('/SearchResult', { state: { results: filteredJobs } });
            setError('');
        }
    };
    
    

    return (
        <div className="container">
         
            <div className='row d-flex'>
                <div className='col-12 col-md-2 col-lg-2'>
                <input className='form-control' type="text" name="jobTitle" placeholder="Job Title" onChange={handleInputChange} />
                </div>
                <div className='col-12 col-md-2 col-lg-2'>
                <input className='form-control' type="text" name="company" placeholder="Company" onChange={handleInputChange} />
                </div>
                <div className='col-12 col-md-2 col-lg-2'>
                <select className='form-select' name="jobType" onChange={handleInputChange}>
                    <option value="All">All</option>
                    <option value="full-time">Full-time</option>
                    <option value="part-time">Part-time</option>
                    <option value="contract">Contract</option>
                </select>
                </div>
                <div className='col-12 col-md-2 col-lg-2'>
                <input className='form-control' type="text" name="skills" placeholder="Skills" onChange={handleInputChange} />
                </div>
                <div className='col-12 col-md-2 col-lg-2'>
                <input className='form-control' type="text" name="locations" placeholder="Locations" onChange={handleInputChange} />
                </div>
                <div className='col-12 col-md-2 col-lg-2'>
                <button className='btn btn-success d-block w-100' onClick={handleSearch}><IoIosSearch className='mx-2'/>Search</button>
                </div>
                
                
                
                
                
            </div>
            {error && <p className='my-5 text-white'>{error}</p>}
        </div>
    );
};

export default JobSearch;
