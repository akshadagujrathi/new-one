import React from 'react';
import SinglejobPost from '../components/Home/SinglejobPost';
import JobBanner from '../components/Job/JobBanner';

const JobPage = () => {
    return (
        <div>
            
            <section className='job-banner'>
            <JobBanner />
            </section>
            <section>
            <SinglejobPost />
            </section>
            
            
        </div>
    );
}

export default JobPage;
